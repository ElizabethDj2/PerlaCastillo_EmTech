"""
Genera la lista de productos vendidos en el mes que se indique
"""



def venta_mensual(mes, lifestore_sales, lifestore_products):

  date = []
  for i in lifestore_sales:
      date.append([i[1], i[3].split('/')])
    
  enero = []
  febrero = []
  marzo = []
  abril = []
  mayo = []
  junio = []
  julio = []
  agosto = []
  septiembre = []
  octubre = []
  noviembre = []
  diciembre = []
    
  for i in date :
      if i[1][1] == '01':
          enero.append(i)
      elif i[1][1] == '02':
          febrero.append(i)
      elif i[1][1] == '03':
          marzo.append(i)
      elif i[1][1] == '04':
          abril.append(i)
      elif i[1][1] == '05':
          mayo.append(i)
      elif i[1][1] == '06':
          junio.append(i)
      elif i[1][1] == '07':
          julio.append(i)
      elif i[1][1] == '08':
          agosto.append(i)
      elif i[1][1] == '09':
          septiembre.append(i)
      elif i[1][1] == '10':
          octubre.append(i)
      elif i[1][1] == '11':
          noviembre.append(i)
      elif i[1][1] == '12':
          diciembre.append(i)

  def prod_mes(mes):
      
    dict_freq = {} #Se crea un diccionario para generar las frecuencias de la lista id_product

    for i in mes:
      if i[0] in dict_freq:
        dict_freq[i[0]] += 1
      else:
         dict_freq[i[0]] = 1

    sortedDict = sorted(dict_freq.items(), key=lambda x: x[1], reverse=True) #Se ordena el diccionario de forma descendente si reverse_op=True, y de forma ascendente en caso contrario.

    for i in sortedDict:
        print(f'{i[1]:3} ventas ==> ID {i[0]:2d} \n  Nombre:{lifestore_products[i[0]-1][1]} \n\n')
        

  meses = [enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre]
  meses_name = ["enero", "febrero","marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]

  
  print("Ventas del mes de", meses_name[mes-1], "\n")

  prod_mes(meses[mes-1])