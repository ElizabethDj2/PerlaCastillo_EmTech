"""
Esta función permite regresar una lista de los productos por calificaciones que recibieron.
  *star : recibe un entero entre 1 y 5 que indica qué calificación se está buscando.
  * lista1 = lifestore_sales. 
  
  * lista2 = lifestore_products.
"""


def score(star, lifestore_sales, lifestore_products):
  res = []
  for i in lifestore_sales:
    if i[2] == star: #Esta condición indica que si la calificación de cada producto es igual a cierta calificación (star) verifique si el producto fue devuelto (refund = 1) o no.
      if i[4] == 1 :
        refund = True
      else :
        refund = False
            
      res.append([i[1], i[2], refund]) #Se guarda una lista de las listas [id_producto, score, refund] de cada producto
  for i in res:
    print("ID:", i[0], "Categoría:", lifestore_products[i[0]-1][3], "Reseña:", i[1], "Devuelto:", i[2])
    print("Nombre:", lifestore_products[i[0]-1][1], "\n") #Se imprime la información


