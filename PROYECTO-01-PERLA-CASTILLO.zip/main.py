
#Importar datos y funciones
from lifestore_file import * 
from listas import ventas_busqueda
from refund import devuelto
from stock import stock
from resenas import score
from venta_mes import venta_mensual

# Banderas para entrar y salir de los ciclos de inicio de sesión
bandera = False 
bandera2 = True
i=1


# Inicio de sesión: Validación de usuarios. 
while bandera2 == True:

  if i >1: 
    print("\n", i, "° Intento")



  user = input("\nBienvenido a LifeStore \n  \n Ingrese su usuario:")

  if user == "PerlaCastillo":
    pswd = input("\n \n Ingrese su contraseña:")
    if pswd == "EmTech":
      print("\n \n Inicio de sesión exitosa")
      bandera = True
      bandera2 = False
    
    else:
      print("\n Contraseña inválida")
      i+=1
  else:
    print("\n El usuario no existe")
    i+=1

  if i ==4:
    print("Lo sentimos, completó el límite de intentos")
    bandera2 = False




# Inicio de sesión : Menú y submenús
while bandera == True :

    # Menú
    print("\n Menú: \n 1 Ventas \n 2 Búsquedas \n 3 Stock \n 4 Reseñas \n 5 Resumen de ingresos mensuales \n 6 Resumen de ventas mensuales\n")
    
    option = int(input("\nSeleccione una opción del menú o presione '9' para salir: "))
    
    # Submenú 1 (Se hace un llamado a las funciones correspondientes)
    if option ==1 :
        print("\nSeleccione una opción: \n 1 Productos más vendidos \n 2 Productos rezagados \n 3 Ventas por categoría \n 4 Devoluciones \n 5 Productos vendidos por mes \n 6 Regresar al menú \n")
        
        option = int(input(": "))
        
        if option == 1:
            print("Lista de productos MÁS VENDIDOS: \n")
            reverse_op = True 
            categoria=False
            ventas_busqueda(reverse_op, categoria, lifestore_sales, lifestore_products )
            
            
        elif option == 2:
            print("Lista de productos rezagados: \n")
            reverse_op = False
            categoria=False
            ventas_busqueda(reverse_op , categoria, lifestore_sales, lifestore_products )
            
        elif option == 3:
            print("VENTAS por categoría:\n")
            reverse_op = True
            categoria=True
            ventas_busqueda(reverse_op, categoria, lifestore_sales, lifestore_products  )
                
        elif option == 4: 
            print("Productos que fueron devueltos a la tienda: \n")
            devuelto(lifestore_sales, lifestore_products )
        
        elif option == 5:

          print("Ingrese el mes que desea consultar (1-12): \n")

          mes = int(input())

          venta_mensual(mes, lifestore_sales, lifestore_products)
          
                
        elif option == 6: 
          continue
    # Submenú 2
    elif option == 2:
        
        print("\nSeleccione una opción: \n 1 Productos más buscados \n 2 Productos menos buscados \n 3 Búsquedas por categoría \n 4 Regresar al menú \n")
        
        option = int(input(": "))
        
        if option == 1:
            print("Lista de productos MÁS BUSCADOS: \n")
            reverse_op = True
            categoria=False
            ventas_busqueda(reverse_op, categoria, lifestore_searches, lifestore_products)
            
        elif option == 2:
            print("Lista de productos MENOS BUSCADOS: \n")
            reverse_op = False
            categoria=False
            ventas_busqueda(reverse_op, categoria, lifestore_searches, lifestore_products )
            
        elif option == 3:
            print("BÚSQUEDAS por categoría: \n")
            reverse_op = True
            categoria=True
            ventas_busqueda(reverse_op, categoria, lifestore_searches, lifestore_products  )

        elif option == 4: 
            continue
    # Submenú 3
    elif option == 3 :

      print("\n Cantidad de productos en Stock por categoría: \n")

      stock(lifestore_products)
    # Submenú 4
    elif option == 4 :

      print("\n Submenú \n 1 Productos con mejores calificicaciones (puntuación 5) \n 2 Productos con calificaciones 3 ó 4 \n 3 Productos con peores calificaciones (puntuación 1 ó 2) \n 4 Regresar al menú \n")

      option = int(input(": "))

      if option == 1:
        print("\nProductos con la mejor calificación (5 puntos)\n")
        score(5, lifestore_sales, lifestore_products)

      elif option == 2 :
        print("\nProductos con calificaciones de 3 y 4 puntos\n")
        score(4, lifestore_sales, lifestore_products)
        score(3, lifestore_sales, lifestore_products)


      elif option == 3 :
        print("\nProductos calificaciones de 1 y 2 puntos\n")
        score(2, lifestore_sales, lifestore_products)
        score(1, lifestore_sales, lifestore_products)
      
      elif option == 4:
        continue
    
    elif option == 5:

      date = []
      for i in lifestore_sales:
        date.append([i[1], i[3].split('/')]) #La variable date es subconjunto de la variable lifestore_sale, incluye solamente el id del producto y la fecha, la cuál es desagregada en una lista que contiene lo siguiente : ["día","mes","año"]
    
    
      # Se crean contenedores vacíos para almacenar los datos de cada mes
      enero = []
      febrero = []
      marzo = []
      abril = []
      mayo = []
      junio = []
      julio = []
      agosto = []
      septiembre = []
      octubre = []
      noviembre = []
      diciembre = []
    
      # El siguiente ciclo for permite agrupar la información en los contenedores correspondientes
      for i in date :
        if i[1][1] == '01':
          enero.append(i)
        elif i[1][1] == '02':
          febrero.append(i)
        elif i[1][1] == '03':
          marzo.append(i)
        elif i[1][1] == '04':
          abril.append(i)
        elif i[1][1] == '05':
          mayo.append(i)
        elif i[1][1] == '06':
          junio.append(i)
        elif i[1][1] == '07':
          julio.append(i)
        elif i[1][1] == '08':
          agosto.append(i)
        elif i[1][1] == '09':
          septiembre.append(i)
        elif i[1][1] == '10':
          octubre.append(i)
        elif i[1][1] == '11':
          noviembre.append(i)
        elif i[1][1] == '12':
          diciembre.append(i)

      #La siguiente función permite sumar los ingresos de cada producto para obtner el total del mes
      def venta(mes):
        venta_total = 0
          
        for i in mes:
          venta_total += lifestore_products[i[0]-1][2]
        return venta_total
    
      #Se crea una lista de listas con la información de cada mes
      meses = [enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre]

      #Nombres de los meses
      meses_name = ["enero", "febrero","marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


      ventas_mes = []
      for i in meses:
        ventas_mes.append(venta(i)) # Este ciclo itera sobre la lista meses y llama a la función venta() para cada elemento.

      venta_anual = 0
      para_ordenar = []

      print("Ingreso mensual")    
      for i in range(len(meses_name)):
        print(f'{meses_name[i]:12} ==> $ {ventas_mes[i]:10d}')
            
        para_ordenar.append([meses_name[i], ventas_mes[i]])
            
        venta_anual += ventas_mes[i] #Se suman los ingresos mensuales
           
      print("\n Ingreso anual", venta_anual)  


      para_ordenar = sorted(para_ordenar, key = lambda x:x[1], reverse = True)



      print("\n Los meses con mayor ingreso en el año fueron: \n")

      j=0

      while j <= 2 : #imprime los primeros 3 elementos de la lista ordenada
        print(f'{para_ordenar[j][0]:12} ==> $ {para_ordenar[j][1]:10d}')
        j+=1


    elif option == 6:

    
      date = []
      for i in lifestore_sales:
          date.append([i[1], i[3].split('/')])
          
      enero = []
      febrero = []
      marzo = []
      abril = []
      mayo = []
      junio = []
      julio = []
      agosto = []
      septiembre = []
      octubre = []
      noviembre = []
      diciembre = []
        
      for i in date :
          if i[1][1] == '01':
              enero.append(i)
          elif i[1][1] == '02':
              febrero.append(i)
          elif i[1][1] == '03':
              marzo.append(i)
          elif i[1][1] == '04':
              abril.append(i)
          elif i[1][1] == '05':
              mayo.append(i)
          elif i[1][1] == '06':
              junio.append(i)
          elif i[1][1] == '07':
              julio.append(i)
          elif i[1][1] == '08':
              agosto.append(i)
          elif i[1][1] == '09':
              septiembre.append(i)
          elif i[1][1] == '10':
              octubre.append(i)
          elif i[1][1] == '11':
              noviembre.append(i)
          elif i[1][1] == '12':
              diciembre.append(i)


      meses = [enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre]
      meses_name = ["enero", "febrero","marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]

      ventas_totales = 0
      para_ordenar = []

      print("Promedio de ventas por mes\n")

      for i in range(len(meses_name)):
          print(f'{meses_name[i]:12} ==> {len(meses[i]):10d} ventas')
          
          ventas_totales += len(meses[i])

          para_ordenar.append([meses_name[i], len(meses[i])])
          
          
      print("\nTotal de ventas anual:", ventas_totales) 


      para_ordenar = sorted(para_ordenar, key = lambda x:x[1], reverse = True)



      print("\n Los meses con mayores ventas en el año fueron: \n")

      j=0

      while j <= 2 : 
          print(f'{para_ordenar[j][0]:12} ==> {para_ordenar[j][1]:10d}')
          j+=1

          
        # Salida       
    elif option == 9 :
            
          bandera = False
            
          print("\n Sesión cerrada")
        
        
    else:
        
      print("Opción Inválida")
    

        
    