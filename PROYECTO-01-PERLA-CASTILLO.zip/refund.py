"""
Esta función permite regresar una lista de los productos que fueron vendidos y se devolvieron a la tienda, se agrega el puntaje que se le dió al producto. 

La función puede recibe como parámetros las listas de consulta

  * lista1 = lifestore_sales. 
  
  * lista2 = lifestore_products.
"""

def devuelto(lista1,lista2):

    print("Lista de productos que fueron vendidos y devueltos a la tienda\n")
    refund = []   
    for i in lista1: 
        if i[4] == 1: # Esta condición permite obtener todos los productos que fueron devueltos (refund=1)
            print("ID: ", i[1], "Score: ", i[2], "Date: ", i[3])
            refund.append(i[1])
        
        
    refund = set(refund)  #Se obtiene el conjunto de los productos que fueron devueltos.

    print("\n Nombre de los productos:\n")

    ID=[]

    for i in refund:
    
        ID.append(lista2[i-1][0])
    
    ID = sorted(ID)


    for i in ID:
        print("ID: ", i, "     Stock: ", lista2[i-1][4] )
        print("Producto: ", lista2[i-1][1], "\n" )
    