"""
Esta función permite regresar las listas de Ventas y Búsquedas. 


La función puede recibir los siguiente parámetros:
  
  * reverse_op=True si la lista va a ordenar de mayor a menor las frecuencias de venta o búsqueda,  reverse_op=False en caso contrario.

  * categoria=True si la lista a generar se mostrará por categorías, categoria=False si se mostrará por productos.

  * lista = lifestore_sales para listar ventas, lista = lifestore_searches para listar búsquedas. 
  
  * consulta = lifestore_products para llamar la lista que contiene los datos de todos los productos que maneja LifeStore.
"""



def ventas_busqueda (reverse_op, categoria, lista, consulta):
    
    top = 20 # Se define que las listas mostraran sólo 20 productos.
    
    id_product = [] 
        
    for i in lista:
        id_product.append(i[1])  #Se extrae la lista con el id de los productos vendidos o buscados
    
    
    if categoria == False: 
            
        
        dict_freq = {} #Se crea un diccionario para generar las frecuencias de la lista id_product

        for iD in id_product:
            if iD in dict_freq:
                dict_freq[iD] += 1
            else:
                dict_freq[iD] = 1

        sortedDict = sorted(dict_freq.items(), key=lambda x: x[1], reverse=reverse_op) #Se ordena el diccionario de forma descendente si reverse_op=True, y de forma ascendente en caso contrario.

        top_id = []
        top_freq = []
        top_name = []

        for i in range(0,top): #Se genera el la lista de los productos con su id y frecuencia.
            top_id.append(sortedDict[i][0])
            top_freq.append(sortedDict[i][1])
    

        for i in top_id:
            top_name.append(consulta[i-1][1]) #Se generan los nombres para los productos de la lista anterior.

            
        for i in range(0,top):
            print("Ranking: ", i+1, "°      ID: " , top_id[i], "    Frecuencia:",  top_freq[i])
            print("Producto: ", top_name[i], "\n")  #Se imprime la lista final
    
        
    elif categoria == True:
        
        category = []

        for i in id_product:
             category.append(consulta[i-1][3]) #Se genera una lista con las categorias de los productos vendidos o buscados.

        dict_freq = {} #Se crea un diccionario para generar las frecuencias con que aparece cada categoría en la lista category.

        for iD in category:
            if iD in dict_freq:
                dict_freq[iD] += 1
            else:
                dict_freq[iD] = 1

        sortedDict = sorted(dict_freq.items(), key=lambda x: x[1], reverse=reverse_op) #Se ordena el diccionario dict_freq y se guarda en la variable sortedDict


        for i in sortedDict:
          print("Categoría: ", i[0], "    Frecuencia: ", i[1], "\n")