"""
Esta función permite regresar una lista de los productos por categoría que se tienen en stock, sólo requiere de la lista de consulta lista = lifestore_products
"""

def stock(lista):

  stock = []

  for i in lista:
      stock.append([i[3],i[4]]) #Se obtiene una lista de las listas [categoría, stock] de cada producto.
    
    
  dict_freq = {} #Se crea un diccionario para generar las frecuencias de la lista stock por categoría.

  for i in stock:
      if i[0] in dict_freq:
          dict_freq[i[0]] += i[1] 
      else:
          dict_freq[i[0]] = i[1]

  sortedDict = sorted(dict_freq.items(), key=lambda x: x[1]) #Se ordena el diccionario de forma descendente
  for i in sortedDict:
      print("Stock: ", i[1], "    Categoría: ", i[0])