#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 12 12:27:48 2021

@author: perla
"""

# Librerías
import pandas as pd 
from collections import Counter

# En la siguiente variable se define el medio de transporte para el cuál se busca información
# Puede ser "Sea" "Air" "Rail" "Road"

seleccion = "Road"

# Leer base de datos
data = pd.read_csv("synergy_logistics_database.csv")


# Se genera una nueva variable llamada ruta 
data["ruta"] = data["origin"] + "-" + data["destination"]



# Se genera una lista que contiene diccionarios

lista = []

for i in range(len(data["ruta"])):
    
    lista.append({"transporte": data["transport_mode"][i], "ruta":data["ruta"][i], "valor": data["total_value"][i] })
    


# Se buscan todos los registros que coincida con la variables seleccion como medio de transporte

# Y se guardan las rutas correspondientes

ruta_mar = []
    
for i in range(len(lista)):
    if lista[i]["transporte"] == seleccion:
        ruta_mar.append(lista[i].get("ruta"))

        
print("\n Rutas que se realizan por", seleccion, "y cantidad de veces que se realizaron:\n\n", Counter(ruta_mar))        


# Se cuenta el número de veces de cada ruta
lista_values = Counter(ruta_mar).keys()



# Esta función permite obtener los ingresos de cada registro según su ruta

def suma(ruta,trans=seleccion):
    in_ruta = data["ruta"] == ruta
    
    val_for_ruta = data[in_ruta]
    
    in_ruta2 = val_for_ruta["transport_mode"] == trans
    
    val_for_ruta2 = val_for_ruta[in_ruta2]
    
    
    valor = sum(val_for_ruta2["total_value"])
    
    #print(ruta, valor)
    
    return valor


  
# Se recorre la lista que contiene las rutas para obtener su ingreso total

lista_ruta_val = []

for i in lista_values:
    
    k = suma(i)

    
    lista_ruta_val.append([i,k])

lista_ordenada = sorted(lista_ruta_val, key=lambda valor : valor[1], reverse = True)


print("\n 10 Rutas por", seleccion, "con mayor ingreso: \n")
   


# Se imprimen sólo los 10 primeros registros
suma_10 = []
for i in range(10):
    print(lista_ordenada[i])
    suma_10.append(lista_ordenada[i][1])

    
suma_total = []
for i in range(len(lista_ordenada)):
    #print(lista_ordenada[i])
    suma_total.append(lista_ordenada[i][1])
    
    


print("\n El ingreso que generan las 10 rutas es el", round(sum(suma_10)*100/sum(suma_total),2), "% del total de las rutas que se hacen por", seleccion)

print("\n El ingreso que generan las 10 rutas es el", round(sum(suma_10)*100/sum(data["total_value"]),2), "del ingreso total")

