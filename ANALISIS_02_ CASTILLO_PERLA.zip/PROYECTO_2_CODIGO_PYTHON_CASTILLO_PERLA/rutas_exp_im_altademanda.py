#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 11 22:33:54 2021

@author: perla
"""

# Librerías
import pandas as pd 
from collections import Counter
# Leer base de datos
data = pd.read_csv("synergy_logistics_database.csv") 
# Se crea una nueva variable llamada ruta
data["ruta"] = data["origin"] + "-" + data["destination"]



# Propuesta 1


def ruta_importacion_exportacion(direction):
     in_direction = data['direction'] == direction
     
     export_import = data[in_direction]
     
     print("\n Número total de rutas para", direction, ":  ", len(export_import))
     
     ruta = [export_import["origin"] + "-" + export_import["destination"]]
     
     main_routes = Counter(ruta[0])
     
     k_routes = main_routes.most_common(10)
     
     return k_routes, export_import




main, exports = ruta_importacion_exportacion("Exports")
main2, imports = ruta_importacion_exportacion("Imports")

print("\n Primeras 10 rutas de exportación de alta demanda: \n" , main)
     
print("\n Primeras 10 rutas de importación de alta demanda: \n" , main2)




def suma(ruta):
    in_ruta = data["ruta"] == ruta
    
    val_for_ruta = data[in_ruta]
    
    valor = sum(val_for_ruta["total_value"])
    
    print(ruta, valor)
    
    return valor
    
print("\nIngreso de las 10 rutas de exportación de alta demanda:")
    
sigma = 0   
lista = []
for i in range(len(main)):
    
    k = suma(main[i][0])
    sigma+=k
    
    lista.append([main[i][0],k])

lista_ordenada = sorted(lista, key=lambda valor : valor[1], reverse = True)

print("\nLista ordenada por ingreso:", lista_ordenada)    


print("\n Representan el", round(sigma*100/sum(exports["total_value"]),2), "% del ingreso total que generan las exportaciones")
    
print("\n Representan el", round(sigma*100/sum(data["total_value"]),2), "% del ingreso total")

print("\Ingreso de las 10 rutas de importación de alta demanda:")

sigma2 = 0
lista2 = []
for i in range(len(main2)):
    k = suma(main2[i][0])
    sigma2 += k
    
    lista2.append([main2[i][0],k])
    
lista_ordenada2 = sorted(lista2, key=lambda valor : valor[1], reverse = True)

print("\nLista ordenada por ingreso:", lista_ordenada2)    
  
print("\n Representan el", round(sigma2*100/sum(imports["total_value"]),2), "% del ingreso total que generan las importaciones")

print("\n Representan el", round(sigma2*100/sum(data["total_value"]),2), "% del ingreso total")



print("\n Ambas rutas representan generan el:", round((sigma+sigma2)*100/sum(data["total_value"]),2), "% del ingreso total")   



dict_from_list = {data["ruta"][i]: data["transport_mode"][i] for i in range(len(data["ruta"]))}


print("\n Principales Rutas de Exportación y su medio de transporte principal:")

for i in range(10):
    
    print(main[i][0], dict_from_list[main[i][0]])


print("\n Principales Rutas de Importación y su medio de transporte principal:")

for i in range(10):
    
    print(main2[i][0], dict_from_list[main2[i][0]])



